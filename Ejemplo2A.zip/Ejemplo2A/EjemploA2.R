#### Apéndice 2. Solución Normalizada de Hidróxido de Sodio ####

#Fecha: 2025-12-28
#Referencia: Ellison, S. L. R. y Williams, A. (2012). Eurachem/CITAC guide: 
#Quantifying Uncertainty in Analytical Measurement, 3rd ed. 
#Disponible en <http://www.eurachem.org>

#Activar paquetes
library(metRology)
library(nortest)

#Definir mensurando
Mensurando <- expression(((1000*mKHP*PKHP)/(MKHP*VT))*sr)

#Fuentes de incertidumbre con su valor asignado
x <- list(mKHP = 0.3888, PKHP = 1, MKHP = 204.2112, VT = 18.64, sr = 1)

#Incertidumbres estándar u(x)
u <- list(0.00013, 0.00029, 0.0038, 0.013, 0.0005)

#Distribución de las incertidumbres estándar u(x).
d <- list("unif", "unif", "unif", "unif", "norm")

#Grados de libertad de las incertidumbres estándar u(x).
df <- list(Inf, Inf, Inf, Inf, 9)

#Activar la función
source("Incertidumbre.R")

#Ejecutar la función sin matriz de correlación
Incertidumbre(Mensurando, x, u, d, df)

